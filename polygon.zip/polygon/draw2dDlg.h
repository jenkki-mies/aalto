// draw2dDlg.h : header file
//

#if !defined(AFX_DRAW2DDLG_H__06224883_14FB_4212_B2C9_BC62EB45DF40__INCLUDED_)
#define AFX_DRAW2DDLG_H__06224883_14FB_4212_B2C9_BC62EB45DF40__INCLUDED_

#include "RenderDlg.h"	// Added by ClassView
#include "Line.h"
#include "matrix.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define MAX_POINTS 20000
#define MAX_OBJECTS 10

#ifndef _NO_NAMESPACE                                                                     
using namespace std;                                                                      
using namespace math;                                                                     
#define STD std                                                                           
#else                                                                                     
#define STD                                                                               
#endif                                                                                    
                                                                                          
#ifndef _NO_TEMPLATE                                                                      
typedef matrix<double> Matrix;                                                            
#else                                                                                     
typedef matrix Matrix;                                                                    
#endif             
/////////////////////////////////////////////////////////////////////////////
// CDraw2dDlg dialog

class CDraw2dDlg : public CDialog
{
// Construction
public:
	Matrix m_mCamera;
	void AddLine(CPoint ptFrom, CPoint ptTo, COLORREF color);
	Matrix m_mRotA;
	void glRotate(int object);
	Matrix m_mOrthographic;
	Matrix m_mPerspective;
	void Translate(int object, int coord, double translation);
	void Scale(int object, int coord, double factor);
	int m_iTransform;
	void Rotate(int object, int coord, double angle);
	void TransformPoints(int object);
	void Rasterize(int object);
	int m_nearDistance;
	int m_farDistance;
	double m_left;
	double m_right;
	double m_top;
	double m_bottom;
	Matrix m_vCameraOrientation;
	Matrix m_vCameraPosition;
	int m_numEdges[MAX_OBJECTS];
	int m_numObjects;
	int m_Faceset[MAX_OBJECTS][MAX_POINTS];
	int m_Colorset[MAX_POINTS];
	BOOL m_bInventor;
	CString m_sInvFile;
	Matrix m_mScale;
	Matrix m_mRot[3];
	Matrix m_mTrans;
	Matrix m_vScale;
	Matrix m_vRot;
	Matrix m_vTrans;
	Matrix m_M[MAX_OBJECTS];
	Matrix m_mTransformedPts[MAX_OBJECTS];
	Matrix m_mPoints[MAX_OBJECTS];
	BOOL m_bDraw2d;
	BOOL m_bUseColor;
	BOOL m_bBmp;
	int m_iTool;
	CBitmap m_bmpBitmap;
	int m_iColor;
	CObArray m_oaLines;
	CDraw2dDlg(CWnd* pParent = NULL);	// standard constructor
	static const COLORREF m_crColors[8];
	void AddLine(CPoint ptFrom, CPoint ptTo);
	void AddPoint(int object, double ptx, double pty, double ptz);
	void AddPoint(int object, double ptx, double pty, double ptz, COLORREF color);
	CLine * GetLine(int nIndex);
	int GetLineCount();

// Dialog Data
	//{{AFX_DATA(CDraw2dDlg)
	enum { IDD = IDD_DRAW2D_DIALOG };
	CSliderCtrl	m_ZRot;
	CSliderCtrl	m_YRot;
	CSliderCtrl	m_XRot;
	CString	m_sDrawFile;
	int		m_xMin;
	int		m_xMax;
	int		m_xRes;
	int		m_yMax;
	int		m_yMin;
	int		m_yRes;
	int		m_Bytes;
	BOOL	m_bRawBits;
	CString	m_sBmpFile;
	CString	m_sPPMFile;
	BOOL	m_bBresenham;
	int		m_thetaX;
	int		m_thetaY;
	int		m_thetaZ;
	CString	m_sScrollTransform;
	CString	m_sPolygonFile;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDraw2dDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	void DeleteContents(BOOL rmLines, BOOL rmPoints);

	// Generated message map functions
	//{{AFX_MSG(CDraw2dDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnFileb();
	afx_msg void OnRender();
	afx_msg void OnChangeXmin();
	afx_msg void OnChangeXmax();
	afx_msg void OnChangeYmin();
	afx_msg void OnChangeYmax();
	afx_msg void OnChangeXres();
	afx_msg void OnChangeYres();
	afx_msg void OnRawbits();
	afx_msg void OnChangeBitmapfile();
	afx_msg void OnBitmapb();
	afx_msg void OnShowBitmap();
	afx_msg void OnPpmfileb();
	afx_msg void OnChangePpmfile();
	afx_msg void OnChangeDrawfile();
	afx_msg void OnHelpAbout();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnBresenham();
	afx_msg void OnInventor();
	afx_msg void OnCustomdrawXRotation(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawYRotation(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawZRotation(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEditchangeCombo1();
	afx_msg void OnUse();
	afx_msg void OnPolygonFile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	RenderDlg m_dlgRender;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAW2DDLG_H__06224883_14FB_4212_B2C9_BC62EB45DF40__INCLUDED_)
