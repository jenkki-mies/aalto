// Pixmap.h: interface for the CPixmap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PIXMAP_H__7776CB40_FA5A_4EAB_86E3_533BD37A4434__INCLUDED_)
#define AFX_PIXMAP_H__7776CB40_FA5A_4EAB_86E3_533BD37A4434__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define MAX_X 1000
#define MAX_Y 1000

class CPixmap : public CObject  
{
public:
	BOOL m_bBresenham;
	void Clear(int resX, int resY);
	int m_yRes;
	int m_xRes;
	COLORREF GetPixel(int x, int y);
	CPoint curPoint;
	void MoveTo(CPoint point);
	void LineTo(CPoint To);
	void SetPixel(int x, int y, COLORREF color);
	void DDA(CPoint p1, CPoint p2, BOOL x);
	void Bresenham(CPoint p1, CPoint p2, BOOL x_step);
	void Swap_Pts(CPoint *point1, CPoint *point2);
	COLORREF map[MAX_X][MAX_Y];
	CPixmap(int xRes, int yRes);
	CPixmap();
	virtual ~CPixmap();

};

#endif // !defined(AFX_PIXMAP_H__7776CB40_FA5A_4EAB_86E3_533BD37A4434__INCLUDED_)
