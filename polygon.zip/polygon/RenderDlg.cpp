// RenderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "draw2d.h"
#include "Pixmap.h"
#include "RenderDlg.h"
#include "draw2dDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const COLORREF RenderDlg::m_crColors[8] = {
	RGB(   0,   0,   0), //Black	
	RGB(   0,   0, 255), //Blue	
	RGB(   0, 255,   0), //Green
	RGB(   0, 255, 255), //Cyan
	RGB( 255,   0,   0), //Red
	RGB( 255,   0, 255), //Magenta
	RGB( 255, 255,   0), //Yellow
	RGB( 255, 255, 255), //White
};

/////////////////////////////////////////////////////////////////////////////
// RenderDlg dialog

RenderDlg::RenderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(RenderDlg::IDD, pParent)
{
	m_map = new CPixmap();

	//{{AFX_DATA_INIT(RenderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void RenderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(RenderDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(RenderDlg, CDialog)
	//{{AFX_MSG_MAP(RenderDlg)
	ON_WM_PAINT()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// RenderDlg message handlers

void RenderDlg::DrawLines(CPaintDC *pdc, CWnd *pWnd, int iColor)
{
	int i;  // line index
	CPen lSolidPen(PS_SOLID, 1, m_crColors[iColor]);
	CDraw2dDlg *lpWnd = (CDraw2dDlg *)pWnd;
	CPen *lOldPen = pdc->SelectObject(&lSolidPen);
	CLine *line;

	if (!m_bPixMapStored) {
		m_map->Clear(lpWnd->m_xRes, lpWnd->m_yRes);
		m_bPixMapStored = TRUE;
		m_map->m_bBresenham = lpWnd->m_bBresenham;
	}
	for (i = 0; i < lpWnd->GetLineCount(); i++) 
	{
		line = lpWnd->GetLine(i);
		if (lpWnd->m_bUseColor) {
			CPen lNewPen(PS_SOLID, 1, line->m_crColor);
			pdc->SelectObject(&lNewPen);
		}
		m_map->MoveTo(line->m_ptFrom);
		pdc->MoveTo(line->m_ptFrom);
		m_map->LineTo(line->m_ptTo);
		pdc->LineTo(line->m_ptTo);
		
	}
	pdc->SelectObject(lOldPen);
}


void RenderDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	CDraw2dDlg *pWnd = (CDraw2dDlg *)GetParent();
	if (pWnd)
	{
		// Reset the resolution to new window size...
		pWnd->m_xRes = cx;
		pWnd->m_yRes = cy;
		m_bPixMapStored = FALSE;
		// cause a repaint... of the rendering
		Invalidate();
		// redisplay the xRes and yRes.
		pWnd->UpdateData(FALSE);

	}
	
}

void RenderDlg::ShowBitmap(CPaintDC *pdc, CWnd *pWnd)
{
	CDraw2dDlg *lpWnd = (CDraw2dDlg *)pWnd;
	BITMAP bm;
	// get the loaded bitmap
	lpWnd->m_bmpBitmap.GetBitmap(&bm);
	CDC dcMem;
	// create a device context to load the bitmap into	
	dcMem.CreateCompatibleDC(pdc);
	//Select the bitmap into the compatible	device context
	CBitmap *pOldBitmap = (CBitmap *)dcMem.SelectObject(lpWnd->m_bmpBitmap);
	CRect lRect;
	GetClientRect(lRect);
	lRect.NormalizeRect();
	// copy and resize the bitmap to the dialog window
	pdc->StretchBlt(10, 10, (lRect.Width() - 20), 
		(lRect.Height() - 20), &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);
}

void RenderDlg::OnPaint() 
{
	CPaintDC dc(this);
	CDraw2dDlg *pWnd = (CDraw2dDlg *)GetParent();
	if (pWnd)
	{
		// is the tool a 2d rendering
		if (pWnd->m_iTool == 0) {
			if (pWnd->m_bDraw2d)
			{
			// is there a bitmap selected and loaded
				DrawLines(&dc, pWnd, pWnd->m_iColor);
			}
		}
		// for bitmap display
		else if (pWnd->m_iTool == 1) {
			if (pWnd->m_bBmp)
				ShowBitmap(&dc, pWnd);
		}
		// for ppm display
		else if (pWnd->m_iTool == 2) {
			if (pWnd->m_bBmp)
				ShowBitmap(&dc, pWnd);
		}
		else if (pWnd->m_iTool == 3) {
			if (pWnd->m_bInventor) {
				//Draw3D(&dc, pWnd);
			}
		}

	}
}

COLORREF RenderDlg::GetPixel(int x, int y)
{
	CPaintDC dc(this);
	return dc.GetPixel(x, y);
}

