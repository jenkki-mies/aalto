// Pixmap.cpp: implementation of the CPixmap class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "draw2d.h"
#include "math.h"
#include "Pixmap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPixmap::CPixmap()
{

}

CPixmap::~CPixmap()
{

}

void CPixmap::SetPixel(int x, int y, COLORREF color)
{
	if (x >= 0 && y >= 0)
		if (x < m_xRes && y <  m_yRes)
			map[x][y] = color;
}

void CPixmap::MoveTo(CPoint point)
{
	curPoint = point;
}

COLORREF CPixmap::GetPixel(int x, int y)
{
	if (x < m_xRes && y <  m_yRes)
		return map[x][y];
	else
		return 0;
}

CPixmap::CPixmap(int xRes, int yRes)
{
	m_xRes = xRes;
	m_yRes = yRes;
}

void CPixmap::Clear(int resX, int resY)
{
	int x, y;
	m_xRes = resX;
	m_yRes = resY;
	for (x = 0; x < MAX_X; x++)
		for (y = 0; y < MAX_Y; y++)
			SetPixel(x, y, 0);

}

void CPixmap::Swap_Pts(CPoint *point1, CPoint *point2)
{
	CPoint tempP;

	tempP = *point1;
	*point1 = *point2;
	*point2 = tempP;
}

void CPixmap::LineTo(CPoint To)
{
	CPoint p1, p2;

	// assume we go from low x to high x...
	p1 = curPoint;
	p2 = To;
	if (p1.x > p2.x) {
		Swap_Pts(&p1, &p2);
	}

	// no line if p1 is the same as p2...
	if (p1 == p2)
	{
		return;
	}

	// avoid division by zero:
	if (p2.x == p1.x)
	{
		int y;
		// vertical line
		// which y is lower, start from it...
		if (p1.y > p2.y) {
			Swap_Pts(&p1, &p2);
		}
		// draw a vertical line
		for (y = p1.y; y < p2.y; y++)
		{
			SetPixel(p1.x, y, (int) 0xffffff);
		}
	}
	else
	{
		// check if slope > 1:
		if (abs(p2.y-p1.y) > (p2.x-p1.x))
		{
			// go from low y to high y
			if (p1.y > p2.y)
				Swap_Pts(&p1, &p2);
			if (m_bBresenham)
				Bresenham(p1, p2, FALSE);
			else
				DDA(p1, p2, FALSE);
		}
		else 
		{
			if (m_bBresenham)
				Bresenham(p1, p2, TRUE);
			else
				DDA(p1, p2, TRUE);
		}
	}
	curPoint = To;
}

#define USE_MACRO 0
#if USE_MACRO
#define BRESENHAM( var1, var2 )				\    
		int var2 = p1.var2;					\                
		int var1, dxdy, dn;					\                
		BOOL positive = TRUE;				\                
											\                
		// positive or negative slope...	\                
		if ((p2.var2 - p1.var2) < 0)		\                
			positive = FALSE;				\                
		dn = abs(p2.var2 - p1.var2);		\                
		dxdy = dn + (p1.var1 - p2.var1);	\                
		int F = dxdy;						\                
		for (var1 = p1.var1; var1 <= p2.var1; var1++)		\
		{									\                
			SetPixel(x, y, (int) 0xffffff);	\                
			if (F < 0) 						\                
			{								\                
				F += dn;					\                
			}								\                
			else 							\                
			{								\                
				if (positive)				\                
					var2++;					\                
				else						\                
					var2--;					\                
				F += dxdy;					\                
			}								\                
		}									\                
#endif

void CPixmap::Bresenham(CPoint p1, CPoint p2, BOOL x_step)
{
	// |slope| <= 1
	if (x_step)
	{
#if (!USEMACRO)
		int y = p1.y;
		int x, dxdy, dy;
		BOOL positive = TRUE;

		// positive or negative slope...
		if ((p2.y - p1.y) < 0)
			positive = FALSE;
		dy = abs(p2.y - p1.y);
		dxdy = dy + (p1.x - p2.x);
		int F = dxdy;
		for (x = p1.x; x <= p2.x; x++)
		{
			SetPixel(x, y, (int) 0xffffff);
			if (F < 0) 
			{
				F += dy;
			}
			else 
			{
				if (positive)
					y++;
				else
					y--;
				F += dxdy;
			}
		}
#else
		BRESENHAM(x, y);
#endif
	}
	// |slope| > 1, swap x and y... 
	// almost same algorithm as above...
	else
	{
#if (!USEMACRO)
		int x = p1.x;
		int y, dx, dxdy;
		BOOL positive = TRUE;
		// positive or negative slope...
		if ((p2.x - p1.x) < 0)
			positive = FALSE;
		dx = abs(p2.x - p1.x);
		dxdy = dx + p1.y - p2.y;
		int F = dxdy;
		for (y = p1.y; y <= p2.y; y++)
		{
			SetPixel(x, y, (int) 0xffffff);
			if (F < 0) 
			{
				F += dx;
			}
			else 
			{
				if (positive)
					x++; 
				else
					x--;
				F += dxdy;
			}
		}
#else
		BRESENHAM(y, x);
#endif
	}
}

void CPixmap::DDA(CPoint p1, CPoint p2, BOOL x)
{
	float slope;
	// |slope| <= 1
	if (x) {
		float y = (float) p1.y;
		// calculate the slope
		slope = (p2.y-p1.y)/(float)(p2.x-p1.x);
		int x;
		for(x = p1.x; x <= p2.x; x++) 
		{
			SetPixel(x, (int) floor(y), (int) 0xffffff);
			y += slope;
		}
	}
	// |slope| > 1, swap x and y... 
	// almost same algorithm as above...
	else {
		float x = (float) p1.x;
		slope = (p2.x-p1.x)/(float)(p2.y-p1.y);
		int y;
		for(y = p1.y; y <= p2.y; y++)
		{
			SetPixel((int) floor(x), y, (int) 0xffffff);
			x += slope;
		}
	}
}
