// draw2dDlg.cpp : implementation file
//

#include "stdafx.h"
#include "draw2d.h"
#include "draw2dDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define PI 3.14159
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDraw2dDlg dialog

CDraw2dDlg::CDraw2dDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDraw2dDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDraw2dDlg)
	m_sDrawFile = _T("");
	m_xMin = 0;
	m_xMax = 0;
	m_xRes = 0;
	m_yMax = 0;
	m_yMin = 0;
	m_yRes = 0;
	m_Bytes = 0;
	m_bRawBits = FALSE;
	m_sBmpFile = _T("");
	m_sPPMFile = _T("");
	m_bBresenham = FALSE;
	m_thetaX = 0;
	m_thetaY = 0;
	m_thetaZ = 0;
	m_sScrollTransform = _T("");
	m_sPolygonFile = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDraw2dDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDraw2dDlg)
	DDX_Control(pDX, IDC_Z_ROTATION, m_ZRot);
	DDX_Control(pDX, IDC_Y_ROTATION, m_YRot);
	DDX_Control(pDX, IDC_X_ROTATION, m_XRot);
	DDX_Text(pDX, IDC_DRAWFILE, m_sDrawFile);
	DDX_Text(pDX, IDC_XMIN, m_xMin);
	DDX_Text(pDX, IDC_XMAX, m_xMax);
	DDV_MinMaxInt(pDX, m_xMax, -100, 100);
	DDX_Text(pDX, IDC_XRES, m_xRes);
	DDX_Text(pDX, IDC_YMAX, m_yMax);
	DDX_Text(pDX, IDC_YMIN, m_yMin);
	DDX_Text(pDX, IDC_YRES, m_yRes);
	DDX_Text(pDX, IDD_BYTES, m_Bytes);
	DDV_MinMaxInt(pDX, m_Bytes, 0, 320000000);
	DDX_Check(pDX, IDC_RAWBITS, m_bRawBits);
	DDX_Text(pDX, IDC_BITMAPFILE, m_sBmpFile);
	DDX_Text(pDX, IDC_PPMFILE, m_sPPMFile);
	DDX_Check(pDX, IDC_BRESENHAM, m_bBresenham);
	DDX_Slider(pDX, IDC_X_ROTATION, m_thetaX);
	DDX_Slider(pDX, IDC_Y_ROTATION, m_thetaY);
	DDX_Slider(pDX, IDC_Z_ROTATION, m_thetaZ);
	DDX_CBString(pDX, IDC_COMBO1, m_sScrollTransform);
	DDX_Text(pDX, IDC_POLYGON_FILE, m_sPolygonFile);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDraw2dDlg, CDialog)
	//{{AFX_MSG_MAP(CDraw2dDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FILEB, OnFileb)
	ON_BN_CLICKED(IDC_RENDER, OnRender)
	ON_EN_CHANGE(IDC_XMIN, OnChangeXmin)
	ON_EN_CHANGE(IDC_XMAX, OnChangeXmax)
	ON_EN_CHANGE(IDC_YMIN, OnChangeYmin)
	ON_EN_CHANGE(IDC_YMAX, OnChangeYmax)
	ON_EN_CHANGE(IDC_XRES, OnChangeXres)
	ON_EN_CHANGE(IDC_YRES, OnChangeYres)
	ON_BN_CLICKED(IDC_RAWBITS, OnRawbits)
	ON_EN_CHANGE(IDC_BITMAPFILE, OnChangeBitmapfile)
	ON_BN_CLICKED(IDC_BITMAPB, OnBitmapb)
	ON_BN_CLICKED(IDC_SHOW_BITMAP, OnShowBitmap)
	ON_BN_CLICKED(IDC_PPMFILEB, OnPpmfileb)
	ON_EN_CHANGE(IDC_PPMFILE, OnChangePpmfile)
	ON_EN_CHANGE(IDC_DRAWFILE, OnChangeDrawfile)
	ON_COMMAND(ID_HELP_ABOUT, OnHelpAbout)
	ON_WM_CONTEXTMENU()
	ON_BN_CLICKED(IDC_BRESENHAM, OnBresenham)
	ON_BN_CLICKED(ID_INVENTOR, OnInventor)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_X_ROTATION, OnCustomdrawXRotation)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_Y_ROTATION, OnCustomdrawYRotation)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_Z_ROTATION, OnCustomdrawZRotation)
	ON_CBN_EDITCHANGE(IDC_COMBO1, OnEditchangeCombo1)
	ON_BN_CLICKED(IDC_USE, OnUse)
	ON_BN_CLICKED(IDC_FILEB2, OnPolygonFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDraw2dDlg message handlers

BOOL CDraw2dDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
	//CPaintDC dc(this);
	//dc->SetMapMode(MM_ANSIOTROPIC);
	m_xMax = m_yMax = 2;
	m_xMin = m_yMin = -2;
	m_xRes = 600;
	m_yRes = 500;
	int i;
	for (i = 0; i < MAX_OBJECTS;i++)
		m_numEdges[i] = 0;
	m_numObjects = 0;
	m_iColor = 1; // White
	m_bUseColor = FALSE;
	m_iTool = 0; // 2d rendering
	m_Bytes = 0;
	m_bDraw2d = FALSE; // no 2d data
	m_bBmp = FALSE;    // no bitmap data
	m_bRawBits = TRUE;
	m_bBresenham = TRUE;
	m_iTransform = 0;
	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDraw2dDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDraw2dDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDraw2dDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CDraw2dDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	OnOK();
}

void CDraw2dDlg::OnChangeXmin() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_dlgRender) {
		m_dlgRender.Invalidate();	
		m_dlgRender.m_bPixMapStored = FALSE;
	}
}

void CDraw2dDlg::OnChangeXmax() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_dlgRender) {
		m_dlgRender.Invalidate();	
		m_dlgRender.m_bPixMapStored = FALSE;
	}
}

void CDraw2dDlg::OnChangeYmin() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_dlgRender) {
		m_dlgRender.Invalidate();
		m_dlgRender.m_bPixMapStored = FALSE;
	}
}

void CDraw2dDlg::OnChangeYmax() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_dlgRender) {
		m_dlgRender.Invalidate();
		m_dlgRender.m_bPixMapStored = FALSE;
	}
}

void CDraw2dDlg::OnChangeXres() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_dlgRender) {
//		m_dlgRender.OnSize(nType, cx, cy);
		m_dlgRender.Invalidate();
		m_dlgRender.m_bPixMapStored = FALSE;
	}
}

void CDraw2dDlg::OnChangeYres() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_dlgRender) {
		m_dlgRender.Invalidate();
		m_dlgRender.m_bPixMapStored = FALSE;
	}
}

void CDraw2dDlg::OnBresenham() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
}


void CDraw2dDlg::OnChangeDrawfile() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(FALSE);
}

void CDraw2dDlg::OnChangeBitmapfile() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(FALSE);
}

void CDraw2dDlg::OnChangePpmfile() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(FALSE);
}

void CDraw2dDlg::OnRawbits() 
{
	UpdateData(TRUE);
}

void CDraw2dDlg::OnRender() 
{
	m_iTool = 0;
	UpdateData(FALSE);
	if (!m_dlgRender) {
		// TODO: Add your control notification handler code here
		m_dlgRender.Create(IDD_RENDERDLG, this);
		m_dlgRender.m_bPixMapStored = FALSE; // m_bPixMapStored
	}
	else {
		m_dlgRender.Invalidate();
	}
	m_dlgRender.ShowWindow(SW_SHOW);
}

void CDraw2dDlg::OnShowBitmap() 
{
	// TODO: Add your control notification handler code here
	m_iTool = 1;
	UpdateData(FALSE);
	if (!m_dlgRender) {
		// TODO: Add your control notification handler code here
		m_dlgRender.Create(IDD_RENDERDLG, this);
		m_dlgRender.m_bPixMapStored = FALSE;
	}
	else {
		m_dlgRender.Invalidate();
	}
	m_dlgRender.ShowWindow(SW_SHOW);
}

void CDraw2dDlg::OnFileb() 
{
	double x = 0, y = 0;
	char Str[1024];
	fstream draw2d;
	BOOL firstpt = TRUE;
	CPoint Origin, ptFrom, ptTo;
	int xscale, yscale;
	Origin.x = m_xMin;
	Origin.y = m_yMin;
	xscale = m_xRes / (m_xMax - m_xMin);
	yscale = m_yRes / (m_yMax - m_yMin);

	// Need a filter for 2d files...
	static char BASED_CODE szFilter[] = "2D Files (*.2d)|*.2d||";
	CFileDialog m_ldFile(TRUE, ".2d", m_sDrawFile, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	if (m_ldFile.DoModal() == IDOK)
	{
		m_sDrawFile = m_ldFile.GetFileName();
		if (GetLineCount() > 0)
			DeleteContents(TRUE, TRUE);
		draw2d.open(m_sDrawFile, ios::in);
		while (!draw2d.eof())
		{
			memset(Str, 0, strlen(Str));
			draw2d.getline(Str, 1000, '\n');
			if (strstr(Str,"polyline")) {
				firstpt = TRUE;
			}
			else
			{
				char* ptr = strtok(Str, "\n\t ");
				double number = 0.0;
				if (ptr != NULL) 
				{
					x = strtod(ptr, NULL);
					ptr = strtok(NULL, "\n\t ");
					if (ptr != NULL)
					{
						y = strtod(ptr, NULL);
						ptr = strtok(NULL, "\n\t ");
					}
					else {
						sprintf(Str, "Error in 2d file(y): %s", m_sDrawFile);
						MessageBox(Str);
						return;
					}
					if (firstpt) {
						ptFrom.x = (long) ((x - Origin.x) * xscale);
						ptFrom.y = (long) ((y - Origin.y) * yscale);
						firstpt = FALSE;
					}
					else {
						ptTo.x = (long) ((x - Origin.x) * xscale);
						ptTo.y = (long) ((y - Origin.y) * yscale);
						AddLine(ptFrom, ptTo);
						ptFrom = ptTo;
					}

				}
			}
		}
		m_bDraw2d = TRUE;
		m_dlgRender.m_bPixMapStored = FALSE;
		UpdateData(FALSE);
		if (m_dlgRender)
		{
			m_dlgRender.Invalidate();	
			m_dlgRender.m_bPixMapStored = FALSE;
		}
		if (GetLineCount() > 0)
			OnRender();

	}
}


void CDraw2dDlg::OnBitmapb() 
{
	// TODO: Add your control notification handler code here
	// Need a filter for bitmap files...
	static char BASED_CODE szFilter[] = "Bitmap Files (*.bmp)|*.bmp||";
	CFileDialog m_ldFile(TRUE, ".bmp", m_sBmpFile, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	if (m_ldFile.DoModal() == IDOK)
	{
		m_sBmpFile = m_ldFile.GetFileName();
		UpdateData(FALSE);
		HBITMAP hBitmap = (HBITMAP) ::LoadImage(AfxGetInstanceHandle(),
			m_sBmpFile, IMAGE_BITMAP, 0, 0, 
			LR_LOADFROMFILE | LR_CREATEDIBSECTION);
		// is the handle valid?
		if (hBitmap)
		{
			//delete the current bitmap
			if (m_bmpBitmap.DeleteObject())
			{
				m_bmpBitmap.Detach();
			}
			m_bmpBitmap.Attach(hBitmap);
		}
		m_bBmp = TRUE;
		if (m_dlgRender)
			m_dlgRender.Invalidate();
	}	
}

void CDraw2dDlg::OnPpmfileb() 
{
	// TODO: Add your control notification handler code here
	// Need a filter for 2d files...
	static char BASED_CODE szFilter[] = "Pixmap Files (*.ppm)|*.ppm||";
	CFileDialog m_ldFile(TRUE, ".ppm", m_sPPMFile, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	if (m_ldFile.DoModal() == IDOK)
	{
		m_sPPMFile = m_ldFile.GetFileName();
		char Str[1000];
		fstream ppmfile;
		int filemode;
		// for outputting the pixels
		COLORREF col;
		char r=0, g=0, b=0;
		int x, y;
	
		m_iTool = 0;
		if (!m_dlgRender) {
			// TODO: Add your control notification handler code here
			m_dlgRender.Create(IDD_RENDERDLG, this);
			m_dlgRender.m_bPixMapStored = FALSE;
		}
		else {
			m_dlgRender.Invalidate();
		}
		filemode = ios::in | ios::out | ios::trunc;
		ppmfile.open(m_sPPMFile, filemode);
		if (m_bRawBits) {
			filemode |= ios::binary;
			sprintf(Str, "P6\n#%s\n%d %d\n%d\n", m_sPPMFile,
					m_xRes, m_yRes, 255); 
			ppmfile.write(Str, strlen(Str));
			for (y = 0; y < m_yRes; y++) 
			{
				for (x = 0; x < m_xRes; x++)
				{
					col = m_dlgRender.m_map->GetPixel(x, y);
					r = (char) (col & 0x000000ff);
					g = (char) ((col & 0x0000ff00) >> 8);
					b = (char) ((col & 0x00ff0000) >> 16);
					//write r, g, b bytes one at a time
					ppmfile.put(r);
					ppmfile.put(g);
					ppmfile.put(b);
				}
			}
			m_Bytes = (3 * m_xRes * m_yRes) + strlen(Str);
		}
		else {
			sprintf(Str, "P3\n#%s\n%d %d\n%d\n", m_sPPMFile,
					m_xRes, m_yRes, 255); 
			ppmfile.write(Str, strlen(Str));
			for (y = 0; y < m_yRes; y++) 
			{
				for (x = 0; x < m_xRes; x++)
				{
					col = m_dlgRender.m_map->GetPixel(x, y);
					r = (char) (col & 0x000000ff);
					g = (char) ((col & 0x0000ff00) >> 8);
					b = (char) ((col & 0x00ff0000) >> 16);
					sprintf(Str, "%d %d %d ", r, g, b);
					ppmfile.write(Str, strlen(Str));
				}
				sprintf(Str, "\n");
				ppmfile.write(Str, strlen(Str));
			}
			m_Bytes = (12 * m_xRes * m_yRes) + strlen(Str);
		}
		ppmfile.write(Str, strlen(Str));
		m_dlgRender.ShowWindow(SW_SHOW);
	}
	UpdateData(FALSE);
}



void CDraw2dDlg::OnHelpAbout() 
{
	// TODO: Add your command handler code here
	CAboutDlg	dlgAbout;
	dlgAbout.DoModal();
	
}

void CDraw2dDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CMenu *m_lMenu;
	CPoint m_pPoint;

	m_pPoint = point;
	//ClientToScreen(&m_pPoint);
	m_lMenu = GetMenu();
	m_lMenu = m_lMenu->GetSubMenu(0);
	m_lMenu->TrackPopupMenu(TPM_CENTERALIGN + TPM_LEFTBUTTON, 
		m_pPoint.x, m_pPoint.y, this, NULL);
}

void CDraw2dDlg::AddLine(CPoint ptFrom, CPoint ptTo, COLORREF color)
{
	// Create a new cline
	CLine *pLine = new CLine(ptFrom, ptTo, color);
	try 
	{
		// add a new object to the object array
		m_oaLines.Add(pLine);
		// mark the document as dirty
//		SetModifiedFlag();
	}
	// did we run into a memory exception
	catch (CMemoryException *perr)
	{
		// display a message to the user giving him the bad news
		AfxMessageBox("Out of memory", MB_ICONSTOP | MB_OK);
		// did we create a line object?
		if (pLine)
		{
			// delete it
			delete pLine;
			pLine = NULL;
		}
		// Delete the exception object
		perr->Delete();
	}
}

void CDraw2dDlg::AddLine(CPoint ptFrom, CPoint ptTo)
{
	// Create a new cline
	CLine *pLine = new CLine(ptFrom, ptTo, m_crColors[m_iColor]);
	try 
	{
		// add a new object to the object array
		m_oaLines.Add(pLine);
		// mark the document as dirty
//		SetModifiedFlag();
	}
	// did we run into a memory exception
	catch (CMemoryException *perr)
	{
		// display a message to the user giving him the bad news
		AfxMessageBox("Out of memory", MB_ICONSTOP | MB_OK);
		// did we create a line object?
		if (pLine)
		{
			// delete it
			delete pLine;
			pLine = NULL;
		}
		// Delete the exception object
		perr->Delete();
	}
}

void CDraw2dDlg::AddPoint(int object, double ptx, double pty, double ptz)
{
	// Create a new cline
	try 
	{
		int rows = m_mPoints[object].RowNo();
		int cols = m_mPoints[object].ColNo() + 1;
		// add a new object to the object array
		m_mPoints[object].SetSize(rows, cols);
		m_mPoints[object](0, cols - 1) = ptx;
		m_mPoints[object](1, cols - 1) = pty;
		m_mPoints[object](2, cols - 1) = ptz;
		m_mPoints[object](3, cols - 1) = 1;
		// mark the document as dirty
//		SetModifiedFlag();
	}
	// did we run into a memory exception
	catch (CMemoryException *perr)
	{
		// display a message to the user giving him the bad news
		AfxMessageBox("Out of memory", MB_ICONSTOP | MB_OK);
		// did we create a line object?
		// how do we delete a single matrix column?
		// Delete the exception object
		perr->Delete();
	}
}

void CDraw2dDlg::AddPoint(int object, double ptx, double pty, double ptz, COLORREF color)
{
	// Create a new cline
	try 
	{
		int rows = m_mPoints[object].RowNo();
		int cols = m_mPoints[object].ColNo() + 1;
		// add a new object to the object array
		m_mPoints[object].SetSize(rows, cols);
		m_mPoints[object](0, cols - 1) = ptx;
		m_mPoints[object](1, cols - 1) = pty;
		m_mPoints[object](2, cols - 1) = ptz;
		m_mPoints[object](3, cols - 1) = 1;
		m_Colorset[cols-1] = color;
		// mark the document as dirty
//		SetModifiedFlag();
	}
	// did we run into a memory exception
	catch (CMemoryException *perr)
	{
		// display a message to the user giving him the bad news
		AfxMessageBox("Out of memory", MB_ICONSTOP | MB_OK);
		// did we create a line object?
		// how do we delete a single matrix column?
		// Delete the exception object
		perr->Delete();
	}
}

CLine * CDraw2dDlg::GetLine(int nIndex)
{
	return (CLine*) m_oaLines[nIndex];
}

int CDraw2dDlg::GetLineCount()
{
	return m_oaLines.GetSize();
}

//	CDocument::DeleteContents();
void CDraw2dDlg::DeleteContents(BOOL rmLines, BOOL rmPoints) 
{
	// TODO: Add your specialized code here and/or call the base class
	if (rmLines)
	{
		int liCount = m_oaLines.GetSize();
		int liPos;

		if (liCount)
		{
			for (liPos = 0; liPos < liCount; liPos++)
				delete m_oaLines[liPos];
			m_oaLines.RemoveAll();
			m_bDraw2d = FALSE;
		}
	}
	if (rmPoints)
	{
		if (m_numObjects == 0)
			return;
		int edge, object;
		for (object = 0; object < m_numObjects; object++) 
		{
			m_mPoints[object].SetSize(0, 0);
			m_bInventor = FALSE;
			for (edge = 0; edge < MAX_POINTS; edge++) {
				m_Faceset[object][edge] = 0;
				m_Colorset[edge] = 0;
				m_numEdges[object] = 0;
			}
		}
		m_numObjects = 0;
	}
}

const COLORREF CDraw2dDlg::m_crColors[8] = 
{
	RGB(   0,   0,   0), //Black	
	RGB(   0,   0, 255), //Blue	
	RGB(   0, 255,   0), //Green
	RGB(   0, 255, 255), //Cyan
	RGB( 255,   0,   0), //Red
	RGB( 255,   0, 255), //Magenta
	RGB( 255, 255,   0), //Yellow
	RGB( 255, 255, 255), //White
};

void CDraw2dDlg::OnInventor() 
{
	char Str[1024];
	fstream inventor;
	double number = 0.0;
	BOOL parsing_camera = FALSE, parsing_separator = FALSE;
	BOOL parsing_transform = FALSE, parsing_coordinates = FALSE;
	BOOL parsing_faceset = FALSE, type_known = FALSE;
	char seps[]   = " ,\t\n";
	char *token;
	int row, col, transform, camera, transform_index, object = 0;
	double x, y, z;

	// Need a filter for 2d files...
	static char BASED_CODE szFilter[] = "Transform Files (*.iv)|*.iv||";
	CFileDialog m_ldFile(TRUE, ".iv", m_sInvFile, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	if (m_ldFile.DoModal() == IDOK)
	{
		m_sInvFile = m_ldFile.GetFileName();
		inventor.open(m_sInvFile, ios::in);
		if (m_numObjects > 0) {
			MessageBox("Deleting Contents on Inventor");
			DeleteContents(TRUE, TRUE);
		}
		m_iTool = 3;

		m_vCameraPosition.SetSize(1, 3);
		m_vCameraPosition.Null();
		m_vCameraOrientation.SetSize(1, 4);
		m_vCameraOrientation.Null();
		m_mCamera.SetSize(4, 4);
		m_mCamera.Unit();
		while (!inventor.eof())
		{
			memset(Str, 0, 1024);
			inventor.getline(Str, 1000, '\n');
			row = col = transform = camera = 0;
			x = y = z = 0;
			type_known = FALSE;
			/* Establish string and get the first token: */
			token = strtok( Str, seps );
			while( token != NULL )
			{
				if (!parsing_separator && !parsing_camera) {
					if (!strcmp(token, "Separator")) {
						parsing_separator = TRUE;
						m_numObjects++;
						if (m_numObjects > 1) {
							object++;
						}
						else {
							m_vTrans.SetSize(1, 3);
							m_vRot.SetSize(1, 4);
							m_vScale.SetSize(1, 3);
							m_mTrans.SetSize(4, 4);
							m_mRot[0].SetSize(4, 4);
							m_mRot[1].SetSize(4, 4);
							m_mRot[2].SetSize(4, 4);
							m_mRotA.SetSize(4, 4);
							m_mScale.SetSize(4, 4);
						}
						m_mPoints[object].SetSize(4, 0);
						m_M[object].SetSize(4, 4);
						//initial values for vectors and matrices...
						// null vectors
						m_M[object].Null();
						m_vTrans.Null();
						m_vRot.Null();
						m_vScale.Null();
						m_vScale(0,0) = 1;
						//and unit matrices
						m_mTrans.Unit();
						m_mScale.Unit();
						m_mRotA.Unit();
						transform_index = 0;
					}
					else if (!strcmp(token, "PerspectiveCamera")) {
						parsing_camera = TRUE;
						m_mPerspective.SetSize(4, 4);
						m_mOrthographic.SetSize(4, 4);
						m_mPerspective.Null();
						m_mOrthographic.Null();
					}
					token = NULL;
					continue;
				}
				if (parsing_camera)
				{
					if (!type_known) {
						if (!strcmp(token, "position")) {
							type_known = TRUE;
							camera = 0;
						}
						else if (!strcmp(token, "orientation")) {
							type_known = TRUE;
							camera = 1;
						}
						else if (!strcmp(token, "nearDistance")) {
							type_known = TRUE;
							camera = 2;
						}
						else if (!strcmp(token, "farDistance")) {
							type_known = TRUE;
							camera = 3;
						}
						else if (!strcmp(token, "#left")) {
							type_known = TRUE;
							camera = 4;
						}
						else if (!strcmp(token, "#right")) {
							type_known = TRUE;
							camera = 5;
						}
						else if (!strcmp(token, "#top")) {
							type_known = TRUE;
							camera = 6;
						}
						else if (!strcmp(token, "#bottom")) {
							type_known = TRUE;
							camera = 7;
						}
						else if (!strcmp(token, "}")) {
							m_mPerspective(0,0) = 2 * m_nearDistance/(m_right - m_left);
							m_mPerspective(1,1) = 2 * m_nearDistance/(m_top - m_bottom);
							m_mPerspective(2,2) = -(m_farDistance + m_nearDistance)/(m_farDistance - m_nearDistance);
							m_mPerspective(0,2) = (m_right + m_left)/(m_right - m_left);
							m_mPerspective(1,2) = (m_top + m_bottom)/(m_top - m_bottom);
							m_mPerspective(2,3) = -2 * m_farDistance * m_nearDistance/(m_farDistance - m_nearDistance);
							m_mPerspective(3,2) = -1;
							m_mPerspective.printM("Perspective Matrix1");
							m_mOrthographic(0,0) = 2.0/(m_right - m_left);
							m_mOrthographic(1,1) = 2.0/(m_top - m_bottom);
							m_mOrthographic(2,2) = -2.0/(m_farDistance - m_nearDistance);
							m_mOrthographic(0,3) = (m_right + m_left)/(m_right - m_left);
							m_mOrthographic(1,3) = (m_top + m_bottom)/(m_top - m_bottom);
							m_mOrthographic(2,3) = (m_farDistance + m_nearDistance)/(m_farDistance - m_nearDistance);
							m_mOrthographic(3,3) = 1;
							m_mOrthographic.printM("Orthographic Matrix1");
							parsing_camera = FALSE;
							token = NULL;
							continue;
						}
						/* Get next token: */
						token = strtok( NULL, seps );
						continue;
					}
					else {
						number = strtod(token, NULL);
						switch (camera)
						{
						case 0:
							m_vCameraPosition(0, col++) = number;
							break;
						case 1:
							m_vCameraOrientation(0, col++) = number;
							break;
						case 2:
							m_nearDistance = number;
							break;
						case 3:
							m_farDistance = number;
							break;
						case 4:
							m_left = number;
							break;
						case 5:
							m_right = number;
							break;
						case 6:
							m_top = number;
							break;
						case 7:
							m_bottom = number;
							break;
						}
					}
				}
				if (token[0] == '#') {
					token = NULL;
					continue;
				}
				if (parsing_separator && 
					!parsing_transform &&
					!parsing_coordinates && 
					!parsing_faceset)
				{
					if (!strcmp(token, "Transform")) {
						parsing_transform = TRUE;
						transform_index++;
					}
					else if (!strcmp(token, "Coordinate3")) {
						parsing_coordinates = TRUE;
					}
					else if (!strcmp(token, "IndexedFaceSet")) {
						parsing_faceset = TRUE;
					}
					else if (!strcmp(token, "}")) {
						parsing_separator = FALSE;
						token = NULL;
						continue;
					}
					token = NULL;
					continue;
				}
				if (!strcmp(token, "}"))
				{
					if (parsing_transform) {
						parsing_transform = FALSE;
						if (transform_index == 1) {
							m_M[object] = (m_mTrans * m_mRotA * m_mScale);
						}
						else {
							m_M[object] *= (m_mTrans * m_mRotA * m_mScale);
						}
						m_M[object].printM("TRS Matrix:");
					}
					else if (parsing_coordinates)
						parsing_coordinates = FALSE;
					else if (parsing_faceset)
						parsing_faceset = FALSE;
					else if (parsing_separator)
						parsing_separator = FALSE;
					else if (parsing_camera) {
						parsing_camera = FALSE;
						m_mPerspective.printM("Perspective Matrix2");
					}
					token = NULL;
					continue;
				}
				if (parsing_transform)
				{
					if (!type_known) {
						if (!strcmp(token, "translation")) {
							type_known = TRUE;
							transform = 0;
						}
						else if (!strcmp(token, "rotation")) {
							type_known = TRUE;
							transform = 1;
						}
						else if (!strcmp(token, "scaleFactor")) {
							type_known = TRUE;
							transform = 2;
						}
						/* Get next token: */
						token = strtok( NULL, seps );
						continue;
					}
					number = strtod(token, NULL);
					switch (transform)
					{
					case 0: // Translation
						m_vTrans(0, col++) = number;
						break;
					case 1: // Rotation
						m_vRot(0, col++) = number;
						break;
					case 2: //Scale
						m_vScale(0, col++) = number;
						break;
					}
				}
				else if (parsing_coordinates)
				{
					if (!type_known) {
						if (!strcmp(token, "point")) {
							token = strtok( NULL, seps );
							type_known = TRUE;
							continue;
						}
					}
					if (!strcmp(token, "[")) {
						token = strtok( NULL, seps );
						continue;
					}
					else if (!strcmp(token, "]")) {
						col = 0;
						type_known = FALSE;
						token = NULL;
						continue;
					}
					number = strtod(token, NULL);
					switch (col++)
					{
					case 0: 
						x = number;
						break;
					case 1:
						y = number;
						break;
					case 2:
						z = number;
						break;
					}
					if (col == 3) {
						AddPoint(object, x, y, z);
						col = 0;
					}
				}
				else if (parsing_faceset)
				{
					if (!type_known) {
						if (!strcmp(token, "coordIndex")) {
							token = strtok( NULL, seps );
							type_known = TRUE;
							continue;
						}
					}
					if (!strcmp(token, "[")) {
						token = strtok( NULL, seps );
						continue;
					}
					else if (!strcmp(token, "]")) {
						col = 0;
						type_known = FALSE;
						token = NULL;
						continue;
					}
					number = strtod(token, NULL);
					m_Faceset[object][m_numEdges[object]++] = (int) number;
				}

				/* Get next token: */
				token = strtok( NULL, seps );
			} // end of line
			if (parsing_transform) {
				switch (transform)
				{
				case 0:
					for (row = 0; row < 3; row++)
						m_mTrans(row, 3) = m_vTrans(0, row);
					break;
				case 1:
					glRotate(object);
					break;
				case 2:
					m_mScale(0, 0) = m_vScale(0,0); 
					m_mScale(1, 1) = m_vScale(0,1);
					m_mScale(2, 2) = m_vScale(0,2); 
					break;
				}
			}
		}
		m_dlgRender.m_bPixMapStored = FALSE;
		UpdateData(FALSE);
		for (object = 0; object < m_numObjects; object++) {
			m_mTransformedPts[object].SetSize(4, m_mPoints[object].ColNo());
#if 1
			sprintf(Str, "Object[%d]: Got %d CPoints, %d Edges", object, m_mPoints[object].ColNo(), m_numEdges[object]);
			MessageBox(Str);
			m_vCameraPosition.printM("Camera Position");
			m_vCameraOrientation.printM("Camera Orientation");
			int i;
			for (i = 0; i < 3; i++)
			m_mCamera(i, 3) = m_vCameraPosition(0, i);
			//cameraRotate();
#endif
			if (m_mPoints[object].ColNo() > 0) 
			{
				// Now use the specified transform on the set of points.
				TransformPoints(object);
				// Convert Points To Lines:
				Rasterize(object);
			}
		}
		m_bInventor = TRUE;
		m_bDraw2d = TRUE;
		UpdateData(FALSE);
		if (m_dlgRender)
		{
			m_dlgRender.Invalidate();	
			m_dlgRender.m_bPixMapStored = FALSE;
		}
		else
			OnRender();
	}	
}

void CDraw2dDlg::Rasterize(int object)
{
	int edge = 0; 
	int point_index;
	CPoint Origin, ptFrom, ptTo;
	int xscale, yscale;
	Origin.x = m_xMin;
	Origin.y = m_yMin;
	xscale = m_xRes / (m_xMax - m_xMin);
	yscale = m_yRes / (m_yMax - m_yMin);
	BOOL new_poly = TRUE;
	for (edge = 0; edge < m_numEdges[object]; edge++)
	{
		point_index = m_Faceset[object][edge];
		if (point_index != -1) 
		{
			// Window coordinates
			ptTo.x = (long) ((m_mTransformedPts[object](0, point_index) - Origin.x) * xscale);
			ptTo.y = (long) ((m_mTransformedPts[object](1, point_index) - Origin.y) * yscale);
			// Flip the y axis
			ptTo.y = m_yRes - ptTo.y;
			if (!new_poly) {
				if (m_bUseColor)
					AddLine(ptFrom, ptTo, m_Colorset[point_index]);
				else
					AddLine(ptFrom, ptTo);
			}
			ptFrom = ptTo;
			new_poly = FALSE;
		}
		else
		{
			new_poly = TRUE;
		}
	}
}

void CDraw2dDlg::TransformPoints(int object)
{
	Matrix m(4, 4);
	m = m_mCamera.Inv();
	m_M[object] = m * m_mTrans * m_mRotA * m_mScale;
//	m_M[object] = m_mOrthographic * m_mPerspective * (m_mTrans * m_mRotA * m_mScale);

//	m_mTransformedPts[object] = m_mPerspective * m_M[object] * m_mPoints[object];
	m_mTransformedPts[object] = m_mPerspective *  m_M[object] * m_mPoints[object];
}

void CDraw2dDlg::Rotate(int object, int coord, double angle)
{
	m_mRot[coord].Unit();
	if (coord == 0)
	{
		m_mRot[coord](1, 1) = cos(angle); 
		m_mRot[coord](1, 2) = -sin(angle);
		m_mRot[coord](2, 1) = sin(angle); 
		m_mRot[coord](2, 2) = cos(angle); 
	}
	else if (coord == 1)
	{
		m_mRot[coord](0, 0) = cos(angle); 
		m_mRot[coord](2, 0) = -sin(angle);
		m_mRot[coord](0, 2) = sin(angle); 
		m_mRot[coord](2, 2) = cos(angle); 
	}
	else if (coord == 2)
	{
		m_mRot[coord](0, 0) = cos(angle); 
		m_mRot[coord](0, 1) = -sin(angle);
		m_mRot[coord](1, 0) = sin(angle); 
		m_mRot[coord](1, 1) = cos(angle); 
	}
}

void CDraw2dDlg::Scale(int object, int coord, double factor)
{
	m_mScale.Unit();
	if (coord == 0)
	{
		m_mScale(0, 0) = factor; 
	}
	else if (coord == 1)
	{
		m_mScale(1, 1) = factor;
	}
	else if (coord == 2)
	{
		m_mScale(2, 2) = factor; 
	}
	else if (coord == 3)
	{
		m_mScale(0, 0) = factor; 
		m_mScale(1, 1) = factor;
		m_mScale(2, 2) = factor; 
	}
}

void CDraw2dDlg::Translate(int object, int coord, double translation)
{
	m_mTrans.Unit();
	if (coord == 0)
	{
		m_mTrans(0, 3) = translation; 
	}
	else if (coord == 1)
	{
		m_mTrans(1, 3) = translation;
	}
	else if (coord == 2)
	{
		m_mTrans(2, 3) = translation; 
	}
	else if (coord == 3)
	{
		m_mTrans(0, 3) = translation; 
		m_mTrans(1, 3) = translation;
		m_mTrans(2, 3) = translation; 
	}
}

void CDraw2dDlg::OnCustomdrawXRotation(NMHDR* pNMHDR, LRESULT* pResult) 
{
	double angle, factor;
	int object = 0;

	UpdateData(TRUE);
	if (m_numObjects == 0)
		return;
	if (m_iTransform == 0)
	{
		angle = m_thetaX * (2 * PI) / 100.0;
		Rotate(object, 0, angle);
	}
	else if (m_iTransform == 1)
	{
		if (m_thetaX > 0) 
			factor = m_thetaX;
		else
			factor = 1;
		Scale(object, 3, 3.0 /factor);
	}
	else if (m_iTransform == 2)
	{
		factor = m_thetaX / 100.0;
		Translate(object, 3, factor);
	}
	DeleteContents(TRUE, FALSE);
	TransformPoints(object);
	Rasterize(object);
	if (m_dlgRender)
	{
		m_dlgRender.Invalidate();	
		m_dlgRender.m_bPixMapStored = FALSE;
	}
	m_bInventor = TRUE;
	m_bDraw2d = TRUE;
	*pResult = 0;
}

void CDraw2dDlg::OnCustomdrawYRotation(NMHDR* pNMHDR, LRESULT* pResult) 
{
	double angle;
	int object = 0;

	UpdateData(TRUE);
	if (m_numObjects == 0)
		return;
	angle = m_thetaY * (2 * PI) / 100.0;
	Rotate(object, 1, angle);
	DeleteContents(TRUE, FALSE);
	TransformPoints(object);
	Rasterize(object);
	if (m_dlgRender)
	{
		m_dlgRender.Invalidate();	
		m_dlgRender.m_bPixMapStored = FALSE;
	}
	m_bInventor = TRUE;
	m_bDraw2d = TRUE;
	*pResult = 0;
}

void CDraw2dDlg::OnCustomdrawZRotation(NMHDR* pNMHDR, LRESULT* pResult) 
{
	double angle;
	int object = 0;

	UpdateData(TRUE);
	if (m_numObjects == 0)
		return;
	angle = m_thetaZ * (2 * PI) / 100.0;
	Rotate(object, 2, angle);
	DeleteContents(TRUE, FALSE);
	TransformPoints(object);
	Rasterize(object);
	if (m_dlgRender)
	{
		m_dlgRender.Invalidate();	
		m_dlgRender.m_bPixMapStored = FALSE;
	}
	m_bInventor = TRUE;
	m_bDraw2d = TRUE;
	*pResult = 0;
}


void CDraw2dDlg::OnEditchangeCombo1() 
{
	UpdateData(TRUE);
}

void CDraw2dDlg::OnUse() 
{
	int i;
	UpdateData(TRUE);
	for (i = 0; i < m_numObjects; i++)
		m_M[i].Unit();
	if (m_sScrollTransform == "Rotation")
	{
		m_iTransform = 0;
	}
	else if (m_sScrollTransform == "Scale")
	{
		m_iTransform = 1;
	}
	else if (m_sScrollTransform == "Translation")
	{
		m_iTransform = 2;
	}
}


void CDraw2dDlg::glRotate(int object)
{
	int i, j; Matrix v(1, 3);
	Matrix u(1, 3);
	Matrix S(3,3);
	Matrix M(3,3), I(3,3), Temp(3,3);
	double _v_, a;
	S.Null();
	I.Unit();
	for (i = 0; i < 3; i++)
		v(0,i) = m_vRot(0,i);
	a = m_vRot(0,3);
	_v_ = v.Norm();
	u = (1/_v_)* v;
	S(0,1) = -u(0,2); 
	S(0,2) =  u(0,1); 
	S(1,0) =  u(0,2); 
	S(1,2) = -u(0,0); 
	S(2,0) = -u(0,1); 
	S(2,1) =  u(0,0); 
	M = ~u * u;
	Temp = cos(a) * (I - M);
	Temp += (sin(a) * S);
	M = M + Temp;
	m_mRotA.SetSize(4,4);
	m_mRotA.Unit();
	for (i = 0; i < 3; i++)
		for (j = 0; j < 3; j++)
			m_mRotA(i, j) = M(i, j);
	m_mRotA.printM("Rotation matrixA");
}

void CDraw2dDlg::cameraRotate(int object)
{
	int i, j; Matrix v(1, 3);
	Matrix u(1, 3);
	Matrix S(3,3);
	Matrix M(3,3), I(3,3), Temp(3,3);
	double _v_, a;
	S.Null();
	I.Unit();
	for (i = 0; i < 3; i++)
		v(0,i) = m_vRot(0,i);
	a = m_vRot(0,3);
	_v_ = v.Norm();
	u = (1/_v_)* v;
	S(0,1) = -u(0,2); 
	S(0,2) =  u(0,1); 
	S(1,0) =  u(0,2); 
	S(1,2) = -u(0,0); 
	S(2,0) = -u(0,1); 
	S(2,1) =  u(0,0); 
	M = ~u * u;
	Temp = cos(a) * (I - M);
	Temp += (sin(a) * S);
	M = M + Temp;
	m_mRotA.SetSize(4,4);
	m_mRotA.Unit();
	for (i = 0; i < 3; i++)
		for (j = 0; j < 3; j++)
			m_mRotA(i, j) = M(i, j);
	m_mRotA.printM("Rotation matrixA");
}

void CDraw2dDlg::OnPolygonFile() 
{
	double number = 0, r, g, b, x, y, z;
	char Str[1024];
	fstream polygon;
	char seps[]   = " ,\t\n";
	char *token;
	COLORREF color;
	int row, object = 0, edge = 0, firstpt = 0;

	m_iTool = 0;
	// Need a filter for 2d files...
	static char BASED_CODE szFilter[] = "Polygon Files (*.poly)|*.poly||";
	CFileDialog m_ldFile(TRUE, ".poly", m_sPolygonFile, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	if (m_ldFile.DoModal() == IDOK)
	{
		m_sPolygonFile = m_ldFile.GetFileName();
		if (GetLineCount() > 0)
			DeleteContents(TRUE, TRUE);
		m_mPoints[object].SetSize(4, 0);
		m_mPoints[object].Null();
		m_mTransformedPts[object].SetSize(4, 0);
		m_mTransformedPts[object].Null();
		polygon.open(m_sPolygonFile, ios::in);
		while (!polygon.eof())
		{
			memset(Str, 0, strlen(Str));
			polygon.getline(Str, 1000, '\n');
			token = strtok( Str, seps );
			row = 0;
			while (token != NULL)
			{
				if (!strcmp(token, "polygon")) {
					if (edge > 0) {
						m_Faceset[object][edge++] = firstpt;
						m_Faceset[object][edge++] = -1;
						firstpt = m_mPoints[object].ColNo();
					}
				}
				else
				{
					double number = strtod(token, NULL);
					switch (row) {
					case 0: 
						x = number;
						break;
					case 1: 
						y = number;
						break;
					case 2: 
						z = number;
						break;
					case 3: 
						r = number * 255;
						break;
					case 4: 
						g = number * 255;
						break;
					case 5: 
						b = number * 255;
						color = ((int) r << 16) +
						((int) g << 8) +
						(int) b;
						AddPoint(0, x, y, z, color);
						m_Faceset[object][edge++] = m_mPoints[object].ColNo() - 1;
						break;
					}
					row++;
				}
				token = strtok( NULL, seps );
			} // end of line
		}  // eof
//		TransformPoints(object);
		// remember to draw a line back to the firstpt to close polygon
		m_Faceset[object][edge++] = firstpt;
		m_Faceset[object][edge] = -1;
		m_numObjects = 1;
		m_bUseColor = TRUE;
		m_numEdges[object] = edge;
		m_mTransformedPts[object] = m_mPoints[object];
//		m_mTransformedPts[object].SetSize(4, m_mPoints[object].ColNo());
		Rasterize(object);
		sprintf(Str, "Rasterized %d Lines, should have %d edges", 
			GetLineCount(), edge);
		MessageBox(Str);
		m_bDraw2d = TRUE;
		UpdateData(FALSE);
		if (m_dlgRender)
		{
			m_dlgRender.Invalidate();	
			m_dlgRender.m_bPixMapStored = FALSE;
		}
		else if (GetLineCount() > 0)
			OnRender();
	}
}
