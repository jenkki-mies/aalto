//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by draw2d.rc
//
#define ID_TRANSFORM                    2
#define ID_INVENTOR                     3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DRAW2D_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_RENDERDLG                   129
#define IDR_MENU1                       132
#define IDC_XMIN                        1000
#define IDC_XRES                        1001
#define IDC_YMIN                        1002
#define IDC_YMAX                        1003
#define IDC_XMAX                        1004
#define IDC_YRES                        1005
#define IDC_DRAWFILE                    1006
#define IDC_RENDER                      1007
#define IDC_FILEB                       1008
#define IDC_PPM_BUTTON                  1009
#define IDC_FILEB2                      1009
#define IDD_BYTES                       1010
#define IDD_PPM_FILE                    1011
#define IDC_POLYGON_FILE                1011
#define IDC_PPMFILEB                    1012
#define IDC_BITMAPB                     1013
#define IDC_BITMAPFILE                  1014
#define IDC_RAWBITS                     1015
#define IDC_SHOW_BITMAP                 1016
#define IDC_PPMFILE                     1017
#define IDC_BRESENHAM                   1018
#define IDC_X_ROTATION                  1019
#define IDC_Y_ROTATION                  1020
#define IDC_Z_ROTATION                  1021
#define IDC_COMBO1                      1022
#define IDC_USE                         1023
#define IDC_COMBO2                      1024
#define ID_HELP_ABOUT                   32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
