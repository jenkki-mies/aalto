// Line.h: interface for the CLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINE_H__4EFD5561_F66B_481D_BA22_543B58092635__INCLUDED_)
#define AFX_LINE_H__4EFD5561_F66B_481D_BA22_543B58092635__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLine : public CObject  
{
	DECLARE_SERIAL (CLine)
public:
//	CLine(CPoint ptFrom, CPoint ptTo, UINT nWidth, COLORREF crColor);
	void Serialize(CArchive &ar);
	void Draw(CDC *pDC);
	CLine(CPoint ptFrom, CPoint ptTo, COLORREF crColor);
	CLine();
	virtual ~CLine();
//private:
	COLORREF m_crColor;
	CPoint m_ptTo;
	CPoint m_ptFrom;
};

#endif // !defined(AFX_LINE_H__4EFD5561_F66B_481D_BA22_543B58092635__INCLUDED_)
