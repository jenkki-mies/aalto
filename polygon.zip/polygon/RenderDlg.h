#if !defined(AFX_RENDERDLG_H__CBD24A30_7720_4631_9174_8015C91AA75E__INCLUDED_)
#define AFX_RENDERDLG_H__CBD24A30_7720_4631_9174_8015C91AA75E__INCLUDED_

#include "Pixmap.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RenderDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// RenderDlg dialog

class RenderDlg : public CDialog
{
// Construction
public:
	CPixmap *m_map;
	BOOL m_bPixMapStored;
	COLORREF GetPixel(int x, int y);
	RenderDlg(CWnd* pParent = NULL);   // standard constructor
	static const COLORREF m_crColors[8];


// Dialog Data
	//{{AFX_DATA(RenderDlg)
	enum { IDD = IDD_RENDERDLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(RenderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(RenderDlg)
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void ShowBitmap(CPaintDC *pdc, CWnd *pWnd);
	void DrawLines(CPaintDC *pdc, CWnd *pWnd, int iColor);
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RENDERDLG_H__CBD24A30_7720_4631_9174_8015C91AA75E__INCLUDED_)
